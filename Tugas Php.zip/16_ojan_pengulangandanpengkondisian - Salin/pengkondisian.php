<?php

$angka = 2;
switch ($angka) {
    case 1:
    echo "pemain persib";
    break;
    case 2:
    echo "pemain persebaya";
    break;
    case 3:
    echo "pemain arema";
    break;
    case 4:
    echo "pemain barito";
    break;
    default:
    echo "pemain persija";
    break;
}

?>