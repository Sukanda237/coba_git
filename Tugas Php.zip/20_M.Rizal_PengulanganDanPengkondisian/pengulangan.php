<?php

 for($i =1; $i < 11; $i++){
     echo "<h2>Ini perulangan ke-$i</h2>";
 }

 ?>