<?php

$angka = 1;
switch ($angka) {
    case 1:
    echo "perilaku sangat baik";
    break;
    case 2:
    echo "perilaku baik";
    break;
    case 3:
    echo "perilaku kurang baik";
    break;
    case 4:
    echo "perilaku tidak baik";
    break;
    default:
    echo "sangat tidak baik";
    break;
}

?>
