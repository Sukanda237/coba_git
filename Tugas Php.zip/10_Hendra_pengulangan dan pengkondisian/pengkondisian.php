<?php

$angka = 1;
switch ($angka) {
    case 1:
    echo "ini motor beat";
    break;
    case 2:
    echo "ini motor nmax";
    break;
    case 3:
    echo "ini motor klx";
    break;
    case 4:
    echo "ini motor ninja";
    break;
    default:
    echo "ini motor rusak";
    break;
}

?>
