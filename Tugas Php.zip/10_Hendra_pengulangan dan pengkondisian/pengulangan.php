<?php

 for($i =1; $i < 11; $i++){
     echo "<h2>ini pemenang-$i</h2>";
 }

 ?>