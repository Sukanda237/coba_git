<?php

$angka = 2;
switch ($angka) {
    case 1:
    echo "absen ke 1 ahmad";
    break;
    case 2:
    echo "absen ke 2 ali";
    break;
    case 3:
    echo "absen ke 3 anissa";
    break;
    case 4:
    echo "absen ke 4 azhar";
    break;
    default:
    echo "semua murid";
    break;
}

?>