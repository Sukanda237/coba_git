<?php

for ($i = 0; $i < 10; $i++){
    echo "<h2>absen ke- $i<h2>";
}
?>