<?php

$array = array('PHP', 'PHYTON', 'RUBY');

foreach($array as $key => $value)
{
    echo $key . ' adalah kunci dari : ' . $value .'<br/>';
}

?>