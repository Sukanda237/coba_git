<?php

$angka = 3;
switch ($angka) {
    case 1:
    echo "isi variabel angka adalah mage";
    break;
    case 2:
    echo "isi variabel angka adalah marksman";
    break;
    case 3:
    echo "isi variabel angka adalah assassin";
    break;
    case 4:
    echo "isi variabel angka adalah tank";
    break;
    default:
    echo "isi variabel tidak ditemukan";
    break;
}

?>