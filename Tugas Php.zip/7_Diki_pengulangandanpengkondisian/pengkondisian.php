<?php

$angka = 2;
switch ($angka) {
    case 1:
    echo "nilai 100";
    break;
    case 2:
    echo "nilai 95";
    break;
    case 3:
    echo "nilai 85";
    break;
    case 4:
    echo "nilai 75";
    break;
    default:
    echo "remedial";
    break;
}

?>