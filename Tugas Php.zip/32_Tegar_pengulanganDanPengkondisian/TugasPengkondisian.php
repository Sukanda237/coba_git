<?php

$angka = 1;
switch ($angka) {
    case 1:
    echo "adalah juara umum";
    break;
    case 2:
    echo "adalah juara 2";
    break;
    case 3:
    echo "adalah juara 3";
    break;
    case 4:
    echo "adalah juara 4";
    break;
    default:
    echo "tidak juara";
    break;
}

?>