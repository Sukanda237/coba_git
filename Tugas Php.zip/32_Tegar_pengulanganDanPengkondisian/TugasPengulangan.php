<?php

$ulangi =1;
while ($ulangi <10){
    echo"<p>ini adalah juara ke-$ulangi</p>";
    $ulangi++;
}

?>